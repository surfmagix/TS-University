(function($) {
Drupal.behaviors.myBehavior = {
  attach: function (context, settings) {
  
    $(document).ready(function() {
		$('.navbar .dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
			// Avoid following the href location when clicking
			event.preventDefault(); 
			// Avoid having the menu to close when clicking
			event.stopPropagation(); 
			// If a menu is already open we close it
			$('ul.dropdown-menu [data-toggle=dropdown]').parent().removeClass('open');
			// opening the one you clicked on
			$(this).parent().addClass('open');
			//$(this).parent().children('ul.dropdown-menu').addclass(open);

		});
        
 
		$('.navbar .dropdown-menu > li > a,.dropdown-submenu ul.dropdown-menu li a').on('click', function(e) {
			e.preventDefault();
			location.href = this.href;
			//window.location.href = $(this).attr('href');
		})
		
		/*$(window).resize(function() {
			$('.views_slideshow_singleframe_teaser_section, .views-slideshow-cycle-main-frame, .views-slideshow-cycle-main-frame-row').each(function(){
		var ratio = 387 / 940 ; //put your own height / width of main image style
		$(this).height($(this).width() * ratio);
    });
  });*/
  $(window).load(function(){
	$('.fractionslider').fractionSlider({
		//Plugin options reference
		'controls': 	false,
		'pager': 	true
	});
 
		//$('.slider').fractionSlider();
	
  });
  
	  });
   

  }
  
   
};
})(jQuery);