// JavaScript Document
(function ($) {
  $(window).load(function(){
	$('.fractionslider').fractionSlider({
		//Plugin options reference
		'controls': 	false,
		'pager': 	true
	});
  });
})(jq190);