  <header>
  	<section class="container">
    	<div class="row hidden-xs" id="topheader">
        	<div class="col-sm-6" id="topleft">
            	<?php print render ($page['top_left']); ?>
            </div><!--col-sm-6 end-->
            <div class="col-sm-4 col-sm-offset-2" id="topright">
            	<?php print render ($page['top_right']); ?>
            </div><!--col-sm-6 end-->
        </div><!--row end-->
        
        <!--logo area-->
        <div class="row" id="headerarea">
        	<div class="col-sm-6 col-xs-6" id="headerleft">
            	<!--logo condition start-->
                    <?php if ($logo): ?>
                      <div id="logo">
                      <a class="logo" href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>">
                        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
                      </a>
                      </div>
                    <?php endif; ?>
                    <?php if ($site_name):?>
                    <span id="site-name">
                    <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>"><?php print $site_name; ?></a>
                    </span>
                    <?php endif; ?>
                
		   			 <?php if ($site_slogan):?>
                    <div id="site-slogan">
                    <?php print $site_slogan; ?>
                    </div>
                    <?php endif; ?>
                <!--logo condition start--> 
                    
            </div><!--col-sm-6 end-->
            <div class="col-sm-4 col-sm-offset-2 hidden-xs" id="headerright">
            	<?php print render ($page['header_right']); ?>
            </div><!--col-sm-6 end-->
        </div><!--row end-->
        <!--logo area end-->
    </section><!--container end-->
  </header>
<!-------------------------------------------------------------------------------------------------------------------------------->  
  <!--Navigation start-->
  	<div id="menu">    	
    	<div id="navbar" role="banner" class="navbar navbar-default">
            <div class="navbar-header">
                <!-- .btn-navbar is used as the toggle for collapsed navbar content -->
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
            </div><!--navbar-header end-->
            <?php if (!empty($primary_nav) || !empty($page['navigation'])): ?>
              <div class="navbar-collapse collapse">
                <nav role="navigation">
                  <?php if (!empty($primary_nav)): ?>
                    <?php print render($primary_nav); ?>
                  <?php endif; ?>
                  <?php if (!empty($page['navigation'])): ?>
                    <?php print render($page['navigation']); ?>
                  <?php endif; ?>
                </nav>
              </div><!--navbar-collapse end-->
            <?php endif; ?>                        
        </div><!--navbar end-->
    </div><!--menu end-->
  <!--Navigation end-->
<!-------------------------------------------------------------------------------------------------------------------------------->
  <!--page start-->
  	<div id="wrapper" class="container">
		 <?php if(!empty($page['bannerarea'])) : ?>
            <div class="col-sm-12" id="slideshow">
            	<?php print render($page['bannerarea']); ?>
            </div><!--col-sm-12 end-->
         <?php endif; ?>
        <!--slideshow end-->
        
        <div class="clearfix"></div>
        
        <?php if(!empty($page['tickerarea'])) : ?>
            <div class="col-sm-12">
            	<?php print render($page['tickerarea']); ?>
            </div><!--col-sm-12 end-->
         <?php endif; ?>
        <!--tickerarea end-->
        
        <div class="clearfix"></div>
        
        
        <!--content start-->
        <div class="row" id="content">
        <div class="col-sm-9">
        	<div class="row">
            	<?php if(!empty($page['featured_one'])) : ?>
            	<div class="col-sm-6">
               		<?php print render($page['featured_one']); ?>
                </div><!--col-sm-6 end-->
                <?php endif; ?>
                
                <?php if(!empty($page['featured_two'])) : ?>
                	<div class="col-sm-6">                	
                		<?php print render($page['featured_two']); ?>
                    <div class="clearfix"></div>
                </div><!--col-sm-6 end-->
                <?php endif; ?>
            </div><!--row end-->
            
            <div class="row">
            	<?php if(!empty($page['featured_three'])) : ?>
                    <div class="col-sm-12">
                        <?php print render($page['featured_three']); ?>
                    </div><!--col-sm-12 end-->
                <?php endif; ?>
            </div><!--row end-->
        </div><!--col-sm-9 end-->
        
        <?php if(!empty($page['featured_four'])) : ?>
            <div class="col-sm-3">
               <?php print render($page['featured_four']); ?>
            </div><!--col-sm-3 end-->
        <?php endif; ?>
        </div><!--row end-->
        
        <!--main content start-->
        <div class="row" id="maincontent">
        	<?php if (!empty($page['sidebar_left'])): ?>
                  <aside class="<?php print $sidebar_grid_class; ?>">
                    <?php print render($page['sidebar_left']); ?>
                  </aside>  <!-- /#sidebar-first -->
                <?php endif; ?>
            
                <section class="<?php print $main_grid_class; ?>">
                  <div id="content">
                      <?php if (!empty($page['highlighted'])): ?>
                        <div class="highlighted"><?php print render($page['highlighted']); ?></div>
                      <?php endif; ?>
                      <?php if (!empty($breadcrumb)): print $breadcrumb; endif;?>
                      <a id="main-content"></a>
                      <?php print render($title_prefix); ?>
                      <?php if (!empty($title)): ?>
                        <h1 class="page-header"><?php print $title; ?></h1>
                      <?php endif; ?>
                      <?php print render($title_suffix); ?>
                      
                      <?php print $messages; ?>
                      <?php if (!empty($tabs)): ?>
                        <?php print render($tabs); ?>
                      <?php endif; ?>
                      <?php if (!empty($page['help'])): ?>
                        <?php print render($page['help']); ?>
                      <?php endif; ?>
                      <?php if (!empty($action_links)): ?>
                        <ul class="action-links"><?php print render($action_links); ?></ul>
                      <?php endif; ?>
                      <?php print render($page['content']); ?>
                   </div><!--content end-->
                  
                </section>
            
                <?php if (!empty($page['sidebar_right'])): ?>
                  <aside class="<?php print $sidebar_grid_class; ?>">
                    <?php print render($page['sidebar_right']); ?>
                  </aside>  <!-- /#sidebar-second -->
                <?php endif; ?>
    
        </div><!--row end-->
        <!--main content end-->
        <!--content end-->
        <div class="clearfix"></div>
<!-------------------------------------------------------------------------------------------------------------------------------->        
        <!--carousel start-->
				<?php if(!empty($page['carousel'])) : ?>
                    <div class="col-sm-12 hidden-xs" id="carousel">
                        <div >
                        	<?php print render($page['carousel']); ?>
                        </div><!--carousel end-->
                    </div><!--col-sm-12 end-->
                <?php endif; ?>
        <!--carousel end-->
    </div><!--wrapper end-->
<!-------------------------------------------------------------------------------------------------------------------------------->  
    <!--footer area start-->
    <footer>
    	<div class="footer-blank-space"></div><!--footer blank space end-->
    	<div class="container">
        	<div class="row" id="footercol">
            <?php if(!empty($page['footer_one'])) : ?>
        	<div class="col-sm-3">
            	<?php print render($page['footer_one']); ?>
                    <div class="clearfix"></div>
            </div><!--col-sm-3 end-->
            <?php endif; ?>
            
            <?php if(!empty($page['footer_two'])) : ?>
        	<div class="col-sm-3" id="footercol2">
            	<?php print render($page['footer_two']); ?>
                    <div class="clearfix"></div>
            </div><!--col-sm-3 end-->
            <?php endif; ?>
            
            <?php if(!empty($page['footer_three'])) : ?>
        	<div class="col-sm-3">
            	<?php print render($page['footer_three']); ?>
                    <div class="clearfix"></div>
            </div><!--col-sm-3 end-->
            <?php endif; ?>
            
            <?php if(!empty($page['footer_four'])) : ?>
        	<div class="col-sm-3">
            	<?php print render($page['footer_four']); ?>
                    <div class="clearfix"></div>
            </div><!--col-sm-3 end-->
            <?php endif; ?>
            </div><!--row end-->
            </div><!--container end-->
            
            <div class="clearfix"></div>
            
            <!--copyrightarea start-->
                <div class="container">
                    <div class="row" id="footercopy">
                        	<?php if(!empty($page['footer_menu'])) : ?>
                            <div class="col-sm-8 col-sm-offset-2 col-xs-12" id="footermenu">
                            	<?php print render($page['footer_menu']); ?>
                                <div class="clearfix"></div>
                            </div><!--col-sm-6 end-->
                            <?php endif; ?>
                            <?php if(!empty($page['footer_copyright'])) : ?>
                            <div class="col-sm-8 col-sm-offset-2 col-xs-12" id="copyright">
                            	<?php print render($page['footer_copyright']); ?>
                            </div><!--col-sm-6 end-->
                            <?php endif; ?>
                    </div><!--row end-->
                 </div><!--container end-->
            <!--copyrightarea end-->
        </footer><!--footer-wrapper end-->
    <!--footerarea end-->